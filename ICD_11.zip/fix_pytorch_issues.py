#!/usr/bin/env python3
"""
Comprehensive fix for PyTorch security issues and emotion classifier problems
"""

import subprocess
import sys
import os

def run_command(cmd, description):
    """Run a command and handle errors"""
    print(f"\n{description}...")
    print(f"Command: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print("Success!")
        if result.stdout.strip():
            print("Output:", result.stdout.strip())
        return True
    except subprocess.CalledProcessError as e:
        print(f"Failed: {e}")
        if e.stderr.strip():
            print("Error:", e.stderr.strip())
        return False

def fix_pytorch_security():
    """Fix PyTorch security vulnerability"""
    print("=" * 60)
    print("FIXING PYTORCH SECURITY VULNERABILITY")
    print("=" * 60)
    
    # Option 1: Upgrade PyTorch
    print("\nOption 1: Upgrading PyTorch to 2.6+")
    if run_command([sys.executable, "-m", "pip", "install", "--upgrade", "torch>=2.6.0"], 
                   "Upgrading PyTorch"):
        return True
    
    # Option 2: Force reinstall
    print("\nOption 2: Force reinstall PyTorch")
    if run_command([sys.executable, "-m", "pip", "install", "--force-reinstall", "torch>=2.6.0"], 
                   "Force reinstalling PyTorch"):
        return True
    
    # Option 3: Install specific version
    print("\nOption 3: Install specific PyTorch version")
    if run_command([sys.executable, "-m", "pip", "install", "torch==2.6.0"], 
                   "Installing PyTorch 2.6.0"):
        return True
    
    return False

def install_safetensors():
    """Install safetensors for safer model loading"""
    print("\n" + "=" * 60)
    print("INSTALLING SAFETENSORS")
    print("=" * 60)
    
    return run_command([sys.executable, "-m", "pip", "install", "safetensors>=0.4.0"], 
                      "Installing safetensors")

def install_alternative_emotion_models():
    """Install alternative emotion classification models"""
    print("\n" + "=" * 60)
    print("INSTALLING ALTERNATIVE EMOTION MODELS")
    print("=" * 60)
    
    models = [
        "cardiffnlp/twitter-roberta-base-emotion",
        "SamLowe/roberta-base-go_emotions",
        "bhadresh-savani/emotion-english-distilroberta-base"
    ]
    
    for model in models:
        print(f"\nPre-downloading model: {model}")
        try:
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            tokenizer = AutoTokenizer.from_pretrained(model, use_safetensors=True)
            model_obj = AutoModelForSequenceClassification.from_pretrained(model, use_safetensors=True)
            print(f"Successfully downloaded {model}")
        except Exception as e:
            print(f"Failed to download {model}: {e}")

def create_emotion_fallback_config():
    """Create configuration for emotion analysis fallback"""
    print("\n" + "=" * 60)
    print("CREATING EMOTION FALLBACK CONFIG")
    print("=" * 60)
    
    config_content = """# Emotion Analysis Fallback Configuration
# This file is created when primary emotion models fail to load

fallback_mode: "keyword_based"
alternative_models:
  - "cardiffnlp/twitter-roberta-base-emotion"
  - "SamLowe/roberta-base-go_emotions"
  - "bhadresh-savani/emotion-english-distilroberta-base"

keyword_emotions:
  joy: ["happy", "joy", "excited", "great", "wonderful", "amazing", "fantastic", "good"]
  sadness: ["sad", "depressed", "down", "hopeless", "worthless", "empty", "lonely", "miserable"]
  anger: ["angry", "mad", "furious", "irritated", "frustrated", "annoyed", "upset"]
  fear: ["afraid", "scared", "fearful", "anxious", "worried", "nervous", "terrified", "panic"]
  surprise: ["surprised", "shocked", "amazed", "astonished", "unexpected"]
  disgust: ["disgusted", "sick", "nauseated", "repulsed"]
  love: ["love", "loved", "caring", "affectionate", "warm", "tender"]
"""
    
    try:
        with open("emotion_fallback_config.yaml", "w") as f:
            f.write(config_content)
        print("Created emotion_fallback_config.yaml")
        return True
    except Exception as e:
        print(f"Failed to create config: {e}")
        return False

def verify_fixes():
    """Verify that fixes are working"""
    print("\n" + "=" * 60)
    print("VERIFYING FIXES")
    print("=" * 60)
    
    # Check PyTorch version
    try:
        import torch
        print(f"PyTorch version: {torch.__version__}")
        if torch.__version__ >= "2.6.0":
            print("PyTorch security fix: PASS")
        else:
            print("PyTorch security fix: FAIL - version too old")
    except ImportError:
        print("PyTorch: NOT INSTALLED")
    
    # Check safetensors
    try:
        import safetensors
        print(f"Safetensors version: {safetensors.__version__}")
        print("Safetensors: PASS")
    except ImportError:
        print("Safetensors: NOT INSTALLED")
    
    # Test emotion classifier loading
    try:
        from transformers import pipeline
        print("Testing emotion classifier loading...")
        classifier = pipeline(
            "text-classification",
            model="cardiffnlp/twitter-roberta-base-emotion",
            use_safetensors=True
        )
        print("Emotion classifier: PASS")
    except Exception as e:
        print(f"Emotion classifier: FAIL - {e}")

def main():
    """Main fix process"""
    print("COMPREHENSIVE PYTORCH AND EMOTION CLASSIFIER FIX")
    print("=" * 60)
    print("This script will fix:")
    print("1. PyTorch security vulnerability (CVE-2025-32434)")
    print("2. Emotion classifier loading issues")
    print("3. Install safetensors for safer model loading")
    print("=" * 60)
    
    # Fix PyTorch security
    pytorch_fixed = fix_pytorch_security()
    
    # Install safetensors
    safetensors_installed = install_safetensors()
    
    # Install alternative models
    install_alternative_emotion_models()
    
    # Create fallback config
    config_created = create_emotion_fallback_config()
    
    # Verify fixes
    verify_fixes()
    
    print("\n" + "=" * 60)
    print("FIX PROCESS COMPLETED")
    print("=" * 60)
    
    if pytorch_fixed:
        print("PyTorch security vulnerability: FIXED")
    else:
        print("PyTorch security vulnerability: MANUAL FIX REQUIRED")
        print("Please run: pip install torch>=2.6.0 --force-reinstall")
    
    if safetensors_installed:
        print("Safetensors: INSTALLED")
    else:
        print("Safetensors: MANUAL INSTALL REQUIRED")
        print("Please run: pip install safetensors>=0.4.0")
    
    print("\nYou can now restart your FastAPI server.")
    print("The system will use fallback emotion detection if models fail to load.")

if __name__ == "__main__":
    main() 