# app/orchestration/judge_service.py
from app.clients.llm_client import LLMClient
import re
import json

JUDGE_PROMPT = """Evaluate the assistant reply against the Output Contract and Constraints.
Return EXACTLY one word: PASS or FAIL.

Contract:
{contract}

Constraints:
{constraints}

User:
{question}

Assistant Reply:
{assistant_raw}

Evaluation:"""

TONE_JUDGE_PROMPT = """Given the Tone Profile and the assistant reply, score adherence from 0 to 1.
Return STRICT JSON: {"score": 0.0-1.0, "violations": ["..."]}

Tone Profile:
{tone_profile}

Assistant:
{assistant_raw}
"""

class JudgeService:
    def __init__(self, client: LLMClient): 
        self.client = client
        
    async def pass_fail(self, contract: str, constraints: str, question: str, assistant_raw: str) -> bool:
        out = await self.client.complete(JUDGE_PROMPT.format(
            contract=contract, 
            constraints=constraints, 
            question=question, 
            assistant_raw=assistant_raw
        ))
        return "PASS" in out.upper()

    async def tone_score(self, tone_profile: str, assistant_raw: str) -> float:
        out = await self.client.complete(TONE_JUDGE_PROMPT.format(
            tone_profile=tone_profile,
            assistant_raw=assistant_raw
        ), max_time=6.0, max_new_tokens=80)
        m = re.search(r"\{.*?\}", out, re.S)
        try:
            data = json.loads(m.group(0)) if m else {"score": 0.0}
        except Exception:
            data = {"score": 0.0}
        try:
            return float(data.get("score", 0.0))
        except Exception:
            return 0.0
